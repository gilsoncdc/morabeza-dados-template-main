"""Laboratório 4 (Sessão 7): painel de vendas da Morabeza com pandas e NumPy.

Trabalha com as tabelas completas de 2024 e 2025: vendas, clientes e produtos.
"""
from pathlib import Path

import numpy as np
import pandas as pd


def carregar(pasta: str) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Lê vendas.csv, clientes.csv e produtos.csv da pasta, com os tipos certos."""
    pasta = Path(pasta)  # já feito: assim podes escrever pasta / "vendas.csv"
    # TODO 1: lê os três ficheiros com pd.read_csv(pasta / "nome.csv").
    #         Nas vendas usa parse_dates=["data"]; nos clientes, parse_dates=["data_registo"].
    #         Devolve (vendas, clientes, produtos), por esta ordem.
    raise NotImplementedError("carregar ainda não está feita")


def juntar(vendas: pd.DataFrame, clientes: pd.DataFrame, produtos: pd.DataFrame) -> pd.DataFrame:
    """Uma tabela única: cada venda com a ilha e o tipo do cliente, o produto e o total."""
    # TODO 2: junta às vendas as colunas cliente_id, tipo e ilha dos clientes (merge on="cliente_id")
    #         e as colunas produto_id, nome e categoria dos produtos (merge on="produto_id").
    # TODO 3: cria a coluna total = quantidade * preco_unitario (numa linha, sem ciclos).
    raise NotImplementedError("juntar ainda não está feita")


def faturacao_mensal_por_ilha(df: pd.DataFrame) -> pd.DataFrame:
    """Tabela com uma linha por mês ("AAAA-MM"), uma coluna por ilha e a faturação nas células."""
    # TODO 4: cria uma coluna mes com df["data"].dt.strftime("%Y-%m") e usa
    #         pivot_table(index="mes", columns="ilha", values="total", aggfunc="sum", fill_value=0).
    raise NotImplementedError("faturacao_mensal_por_ilha ainda não está feita")


def top_produtos(df: pd.DataFrame, n: int = 5) -> pd.Series:
    """Os n produtos com maior faturação, do maior para o menor."""
    # TODO 5: groupby("nome")["total"].sum(), ordena do maior para o menor e fica com os n primeiros.
    raise NotImplementedError("top_produtos ainda não está feita")


def quota_por_tipo(df: pd.DataFrame) -> pd.Series:
    """Percentagem da faturação por tipo de cliente, arredondada a uma casa decimal."""
    # TODO 6: soma o total por tipo, divide pela soma de tudo, multiplica por 100 e arredonda (round(1)).
    raise NotImplementedError("quota_por_tipo ainda não está feita")


def aplicar_desconto(df: pd.DataFrame) -> pd.DataFrame:
    """Acrescenta total_com_desconto: 5% de desconto nas linhas com 20 ou mais unidades.

    Vetorizado com np.where, sem ciclos for.
    """
    df = df.copy()
    # TODO 7: df["total_com_desconto"] = np.where(condição, valor_se_verdade, valor_se_falso)
    #         Condição: quantidade >= 20. Com desconto: total * 0.95. Sem desconto: total.
    raise NotImplementedError("aplicar_desconto ainda não está feita")


# ---------------------------------------------------------------- Extensão (opcional)

def otimizar_tipos(df: pd.DataFrame) -> pd.DataFrame:
    """Converte colunas de texto repetitivo em category e reduz os inteiros."""
    # EXTENSÃO: astype("category") nas colunas de texto que se repetem (ilha, tipo, categoria,
    #           nome, produto_id) e pd.to_numeric(..., downcast="integer") em quantidade e preco_unitario.
    raise NotImplementedError("Extensão por fazer")


def formato_longo(tabela: pd.DataFrame) -> pd.DataFrame:
    """Passa a tabela mensal (uma coluna por ilha) para formato longo: mes, ilha, total."""
    # EXTENSÃO: tabela.reset_index().melt(id_vars="mes", var_name="ilha", value_name="total")
    raise NotImplementedError("Extensão por fazer")
